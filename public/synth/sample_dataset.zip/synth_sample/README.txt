Two sample frames from a synthetic dataset of a procedural San Francisco street (Houdini + Karma).
annotations.json  COCO: images (with camera intrinsics, cam_to_world and QA checks), categories, annotations
                  (bbox, RLE mask, area, instance_id, parent_id, bbox_3d in metres).
*/images/         beauty renders, 640x360
*/labels/         _class.png class id per pixel (8-bit, 255 = ignore), _class_vis.png coloured preview,
                  _instance.png object id per pixel (16-bit), _depth.png metres x 256 (16-bit, 0 = no hit),
                  _normal.png surface normal as colour. Labels are rendered at one sample per pixel: exact, aliased edges.
scene/seed_22.json  per-house door, stairs and porch boxes and the exact stair layout (metres, Y up)
Renders were made with a Houdini Apprentice licence; the watermark corner is marked ignore.
